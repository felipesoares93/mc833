#ifndef BASIC
#define BASIC

	typedef enum {false, true} bool;

#endif